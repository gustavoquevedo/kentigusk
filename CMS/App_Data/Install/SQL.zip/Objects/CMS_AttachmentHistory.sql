SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_AttachmentHistory](
	[AttachmentHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[AttachmentName] [nvarchar](255) NOT NULL,
	[AttachmentExtension] [nvarchar](50) NOT NULL,
	[AttachmentSize] [int] NOT NULL,
	[AttachmentMimeType] [nvarchar](100) NOT NULL,
	[AttachmentBinary] [varbinary](max) NULL,
	[AttachmentImageWidth] [int] NULL,
	[AttachmentImageHeight] [int] NULL,
	[AttachmentDocumentID] [int] NOT NULL,
	[AttachmentGUID] [uniqueidentifier] NOT NULL,
	[AttachmentIsUnsorted] [bit] NULL,
	[AttachmentOrder] [int] NULL,
	[AttachmentGroupGUID] [uniqueidentifier] NULL,
	[AttachmentHash] [nvarchar](32) NULL,
	[AttachmentTitle] [nvarchar](250) NULL,
	[AttachmentDescription] [nvarchar](max) NULL,
	[AttachmentCustomData] [nvarchar](max) NULL,
	[AttachmentLastModified] [datetime2](7) NULL,
	[AttachmentHistoryGUID] [uniqueidentifier] NOT NULL,
	[AttachmentSiteID] [int] NOT NULL,
	[AttachmentSearchContent] [nvarchar](max) NULL,
	[AttachmentVariantDefinitionIdentifier] [nvarchar](50) NULL,
	[AttachmentVariantParentID] [int] NULL,
 CONSTRAINT [PK_CMS_AttachmentHistory] PRIMARY KEY NONCLUSTERED 
(
	[AttachmentHistoryID] ASC
)
)

GO
SET ANSI_PADDING ON

GO
CREATE CLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentDocumentID_AttachmentName] ON [dbo].[CMS_AttachmentHistory]
(
	[AttachmentDocumentID] ASC,
	[AttachmentName] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentGUID] ON [dbo].[CMS_AttachmentHistory]
(
	[AttachmentGUID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentIsUnsorted_AttachmentGroupGUID_AttachmentOrder] ON [dbo].[CMS_AttachmentHistory]
(
	[AttachmentIsUnsorted] ASC,
	[AttachmentGroupGUID] ASC,
	[AttachmentOrder] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentSiteID] ON [dbo].[CMS_AttachmentHistory]
(
	[AttachmentSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentVariantParentID] ON [dbo].[CMS_AttachmentHistory]
(
	[AttachmentVariantParentID] ASC
)
GO
SET ANSI_PADDING ON

GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_AttachmentHistory_AttachmentVariantParentID_AttachmentVariantDefinitionIdentifier] ON [dbo].[CMS_AttachmentHistory]
(
	[AttachmentVariantDefinitionIdentifier] ASC,
	[AttachmentVariantParentID] ASC
)
WHERE ([AttachmentVariantDefinitionIdentifier] IS NOT NULL AND [AttachmentVariantParentID] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_AttachmentHistory] ADD  CONSTRAINT [DEFAULT_CMS_AttachmentHistory_AttachmentHistoryGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [AttachmentHistoryGUID]
GO
ALTER TABLE [dbo].[CMS_AttachmentHistory]  WITH CHECK ADD  CONSTRAINT [FK_CMS_AttachmentHistory_AttachmentSiteID_CMS_Site] FOREIGN KEY([AttachmentSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_AttachmentHistory] CHECK CONSTRAINT [FK_CMS_AttachmentHistory_AttachmentSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_AttachmentHistory]  WITH CHECK ADD  CONSTRAINT [FK_CMS_AttachmentHistory_AttachmentVariantParentID_CMS_AttachmentHistory] FOREIGN KEY([AttachmentVariantParentID])
REFERENCES [dbo].[CMS_AttachmentHistory] ([AttachmentHistoryID])
GO
ALTER TABLE [dbo].[CMS_AttachmentHistory] CHECK CONSTRAINT [FK_CMS_AttachmentHistory_AttachmentVariantParentID_CMS_AttachmentHistory]
GO
