SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_Analytics_ProcessLog]
  @SiteID int,
	@Codename nvarchar(250),
	@Culture nvarchar(10),
  @ObjectName nvarchar(450),
  @ObjectID int,
  @Hits int,
  @HourStart datetime2(7),
	@HourEnd datetime2(7),
  @DayStart datetime2(7),
	@DayEnd datetime2(7),
  @WeekStart datetime2(7),
	@WeekEnd datetime2(7),
  @MonthStart datetime2(7),
	@MonthEnd datetime2(7),
  @YearStart datetime2(7),
	@YearEnd datetime2(7),
	@Value float
AS
BEGIN
	SET NOCOUNT ON;

	/* Declare the @statisticsID variable */
	DECLARE @statisticsID int;
	SET @statisticsID = 0;
     SELECT TOP 1 @statisticsID = StatisticsID FROM [Analytics_Statistics]
	WHERE (StatisticsSiteID = @SiteID) 
		AND (StatisticsCode = @Codename) 
		AND ((@ObjectName IS NOT NULL AND StatisticsObjectName = @ObjectName) OR (@ObjectName IS NULL AND StatisticsObjectName IS NULL)) 
		AND ((@ObjectID IS NOT NULL AND StatisticsObjectID = @ObjectID) OR (@ObjectID IS NULL AND StatisticsObjectID IS NULL)) 
		AND ((@Culture IS NOT NULL AND StatisticsObjectCulture = @Culture) OR (@Culture IS NULL AND StatisticsObjectCulture IS NULL));
	
	/* If @statisticsID is 0 insert new record */
	IF @statisticsID = 0
	BEGIN
		INSERT INTO [Analytics_Statistics] (StatisticsSiteID, StatisticsCode, StatisticsObjectName, StatisticsObjectID, StatisticsObjectCulture)
		VALUES (@SiteID, @Codename, @ObjectName, @ObjectID, @Culture);
		/* Get StatisticsID after it was inserted */
        SET @statisticsID = SCOPE_IDENTITY();
	END
	
	/* Declare @hitsID and @hitsCount variables */
	DECLARE @hitsID int
	
	
	/* HOURS */	
	SELECT TOP 1 @hitsID = HitsID FROM [Analytics_HourHits]
	WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@HourStart AND HitsEndTime=@HourEnd
	IF (@hitsID IS NOT NULL)
	BEGIN
	   UPDATE [Analytics_HourHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value)
	   WHERE HitsID = @hitsID
	END
	ELSE
	BEGIN 
	INSERT INTO [Analytics_HourHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
		VALUES (@statisticsID,@HourStart,@HourEnd,@Hits,@Value);
	END
	
	/* DAYS */
	SELECT TOP 1 @hitsID = HitsID FROM [Analytics_DayHits]
	WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@DayStart AND HitsEndTime=@DayEnd;
	IF (@hitsID IS NOT NULL)
	BEGIN
	   UPDATE [Analytics_DayHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value) 
	   WHERE HitsID = @hitsID
	END
	ELSE
	BEGIN
	    INSERT INTO [Analytics_DayHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
		    VALUES (@statisticsID,@DayStart,@DayEnd,@Hits,@Value);
	END	

	
	/* WEEKS */
	SELECT TOP 1 @hitsID = HitsID FROM [Analytics_WeekHits]	
	WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@WeekStart AND HitsEndTime=@WeekEnd;
	IF (@hitsID IS NOT NULL)
	BEGIN
	   UPDATE [Analytics_WeekHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value)
	   WHERE HitsID = @hitsID	   
     END
	ELSE
	BEGIN
	    INSERT INTO [Analytics_WeekHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
			   VALUES (@statisticsID,@WeekStart,@WeekEnd,@Hits,@Value);
     END

	
	/* MONTHS */
	SELECT TOP 1 @hitsID = HitsID FROM [Analytics_MonthHits]	
	WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@MonthStart AND HitsEndTime=@MonthEnd;
	IF (@hitsID IS NOT NULL)
	BEGIN
	   UPDATE [Analytics_MonthHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value)
	   WHERE HitsID = @hitsID	   
     END
	ELSE
	BEGIN
	    INSERT INTO [Analytics_MonthHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
			   VALUES (@statisticsID,@MonthStart,@MonthEnd,@Hits,@Value);
     END
	
	
	/* YEARS */
     SELECT TOP 1 @hitsID = HitsID FROM [Analytics_YearHits]	 
	WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@YearStart AND HitsEndTime=@YearEnd;
	IF (@hitsID IS NOT NULL)
	BEGIN
	   UPDATE [Analytics_YearHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value) 
	   WHERE HitsID = @hitsID	
     END
	ELSE
	BEGIN
	    INSERT INTO [Analytics_YearHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
			   VALUES (@statisticsID,@YearStart,@YearEnd,@Hits,@Value);
     END	
END


GO
